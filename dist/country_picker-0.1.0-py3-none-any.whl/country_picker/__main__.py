"""Main entry point for the country picker application."""

import sys
from .app import run_app

if __name__ == "__main__":
    sys.exit(run_app())
